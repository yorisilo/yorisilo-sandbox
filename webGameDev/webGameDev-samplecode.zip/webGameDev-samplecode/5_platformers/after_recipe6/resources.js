var resources = [{
  name: "levelSprites",
  type: "image",
  src: "levelSprites.png"
}, 
{
  name: "level1",
  type: "tmx",
  src: "level1.tmx"
},
{
  name: "player",
  type: "image",
  src: "player.png"
},
{ name: "titleScreen",
  type: "image",
  src: "titleScreen.png"
} 
];
