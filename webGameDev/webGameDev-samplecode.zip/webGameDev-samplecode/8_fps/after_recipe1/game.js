var Game = function(){
  this.setup = function() {
    alert("running setup");
  };
}
