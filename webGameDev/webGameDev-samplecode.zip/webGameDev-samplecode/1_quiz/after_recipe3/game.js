// alert('Hello world');
// console.log('Hello world');
	


if(jQuery){
  $("#question1").show();
};

